# -*- coding: utf-8 -*-
from . import mail_mail
from . import approvals_template
from . import approvals_request
from . import approvals_wizard
